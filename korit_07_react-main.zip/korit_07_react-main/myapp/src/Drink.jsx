function Drink(props) {
  return <h1>Would you like some {props.drink}?</h1>
}

export default Drink