function Hello() {

  return <h1>Hello 김일</h1>
}

export default Hello;