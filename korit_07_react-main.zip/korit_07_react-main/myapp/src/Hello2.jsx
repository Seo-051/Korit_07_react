function Hello2(props) {

  return <h2>안녕하세요 {props.lastName} {props.firstName}</h2>
}

export default Hello2;