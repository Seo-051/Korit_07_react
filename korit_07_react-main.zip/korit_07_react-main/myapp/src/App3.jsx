import Counter3 from './Counter3';
import MyComponent3 from './MyComponent3';
import './App.css'

function App() {

  return (
    <>
      <Counter3 />
    </>
  );
}

export default App