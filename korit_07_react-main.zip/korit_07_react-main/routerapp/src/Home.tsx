
function Home() {

  return(
    <h3>Home Component</h3>
  );
}

export default Home