// PageNotFound.tsx

function PageNotFound() {

  return <h1>해당 페이지를 찾을 수 없습니다. 404 Not Found</h1>;
}

export default PageNotFound