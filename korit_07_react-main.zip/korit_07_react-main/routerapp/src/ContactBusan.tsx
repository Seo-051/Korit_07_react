//ContactBusan

function ContactBusan() {

  return <h1>부산</h1>
}

export default ContactBusan