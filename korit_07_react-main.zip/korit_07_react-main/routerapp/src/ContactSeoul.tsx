function ContactSeoul() {

  return(
    <h1>서울</h1>
  );
}

export default ContactSeoul