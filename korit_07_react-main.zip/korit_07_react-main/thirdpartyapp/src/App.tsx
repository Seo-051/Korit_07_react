import DatePicker from 'react-date-picker'
import './App.css'

function App() {

  return (
    <>
      <DatePicker />
    </>
  )
}

export default App
