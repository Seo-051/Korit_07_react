import MyForm4 from './MyForm4'
import './App.css'

function App() {

  return (
    <>
      <MyForm4 />
    </>
  );
}

export default App