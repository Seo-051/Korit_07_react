import Hello from "./Hello";

function MyComponent() {

  return(
    <>
      <Hello />
    </>
  );
}

export default MyComponent