import MyForm from './MyForm';
import MyForm3 from './MyForm3';
import './App.css'

function App() {

  return (
    <>
      <MyForm3 />
      <MyForm />
    </>
  );
}

export default App
